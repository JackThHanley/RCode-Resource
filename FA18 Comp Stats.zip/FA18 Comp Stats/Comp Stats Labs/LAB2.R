#154 Lab 2

x <- seq(0,4*pi, len=100)
y <- sin(x)*(x<(2*pi))+sin(3*x)*(x>(2*pi))+rnorm(100, 0, .3)
x <- x/(4*pi)
plot(x,y)
lines(x = x, y = lm1$fitted.values, col = "red")

 
#Picking knots function#
pick.knots <- function(n, space){
  
  knots <- vector("numeric", n)
  while(min(dist(knots)) < space){
    knots <- runif(n)
  }
  return(knots)
}

#Smoothing function
smoother <- function(y, x, h){
  
  fitted_values <- vector("numeric", length(x))
  
  for(i in 1:length(x)){
    
    fitted_values[i] <- sum( y * dnorm( (x[i] - x) / h ) ) /
      sum( dnorm( (x[i] - x) / h ) )
    
  }  
  
  return(fitted_values)
  
}

#Generate Knots
knots <- pick.knots(4, 0.04)


#Basis Function function#
basis.functions <- function(x, knots){
  
  results <- c()
  
  for(i in 1:length(knots)){
    
    basis.function.results <- (x - knots[i]) * c(as.numeric(x > knots[i]))
    results <- cbind(results, basis.function.results)
    
  }
  
  return(results)
  
}

#basis funciton results for each knot
bfs <- basis.functions(x, knots)

#piece-wise linear model
lm1 <- lm(y ~ x + bfs[,1] + bfs[,2] + bfs[,3] + bfs[,4])

#plots
plot(x,y)
lines(x = x, y = lm1$fitted.values, col = "red")


#Smoothing function#

smooth.lm.values <- smoother(lm1$fitted.values, x, 0.02)

#plots of slightly smoothed model
plot(x,y)
lines(x = x, y = smooth.lm.values, col = "red")






#Resid plot
resid.orig <- lm2$residuals
plot(x, lm2$residuals)

#Resid Knots#
knots.resid <- pick.knots(4, 0.04)

bfs.resid <- basis.functions(x, knots.resid)



lm.resid <- lm(resid.orig ~ x + bfs.resid[,1] + bfs.resid[,2] + bfs.resid[,3] + bfs.resid[,4])

plot(x, lm2$residuals)
lines(x = x, y = lm.resid$fitted.values, col = "red")



#Looping, actual Boosting Algorithm#

x <- seq(0,4*pi, len=100)
y <- sin(x)*(x<(2*pi))+sin(3*x)*(x>(2*pi))+rnorm(100, 0, .3)
x <- x/(4*pi)

#Initializing variables#
sse <- c()
fits <- matrix(nrow = 500, ncol = length(x))


#Picking/smoothing first lm#
knots.1 <- pick.knots(4,0.04)
bfs <- basis.functions(x, knots.1)


knots.resid <- pick.knots(4, 0.04)
bfs.resid <- basis.functions(x, knots.resid)

lm1 <- lm(y ~ x + bfs[,1] + bfs[,2] + bfs[,3] + bfs[,4])

smooth.lm.values <- smoother(lm1$fitted.values, x, 0.02) 

#plot(x,y)
#lines(x, smooth.lm.values, col = "red")

for(i in 1:500){
  fits[i,] <- smooth.lm.values
  
  resids <- y - smooth.lm.values
  
  sse[i] <- sum(resids^2)
  
  knots.resid <- pick.knots(4, 0.04)
  bfs.resid <- basis.functions(x, knots.resid)
  
  lm.resid <- lm(resids ~ x + bfs.resid[,1] + bfs.resid[,2] + bfs.resid[,3] + bfs.resid[,4])
  
  lm.new <- smooth.lm.values + lm.resid$fitted.values
  
  smooth.lm.values <- smoother(lm.new, x, 0.01)
  
}

#Plotting of models
plot(x,y)
lines(x, fits[which.max(sse),], col = "blue", lty = 15)
lines(x, fits[250,], col = "darkgreen", lty = 18)
lines(x, fits[which.min(sse),], col = "red")

#Compared to the regularization methods, boosting is not giving us a
# model, i.e., we don't have any parameters. 

#Over the range of the data, the smoothness of our estimator remains constant.
#We have no spiky areas at all over the range of our data.

#When succssive smooths oversmooth a region of the data, it gets "pushed out,"
#leaving us with a worse model then we had before.
#This is why the 500th time we looped it wasn't necessarily best model.
