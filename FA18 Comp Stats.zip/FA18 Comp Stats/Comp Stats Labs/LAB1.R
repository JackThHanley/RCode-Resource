#Comp Stats Lab 1
#Jack Hanley

library(readr)
xkcd <- read_csv("~/Comp_Stats_Labs/xkcd")

library(ggplot2)

xkcd %>%
  ggplot(aes(x= x, y = y)) +
    geom_point() 
    


#Assume only continuity#

#Function thta gives cross validated h value#
hs.xkcd.loocv <- function(min, max, length){
  
  hs <- seq(min, max, length)
  
  MSE <- vector("numeric", length(hs))
  
  for(h in hs){
    
    fitted_value <- vector("numeric", nrow(xkcd))
    
          for(i in 1:nrow(xkcd)){
      
        
            fitted_value[i] <- sum( xkcd$y[-i] * dnorm( (xkcd$x[-i] - xkcd$x[i]) / h ) ) /
                               sum( dnorm( (xkcd$x[-i] - xkcd$x[i]) / h ))
            
          }  
    
    MSE[match(h, hs)] <- sum((xkcd$y - fitted_value)^2) / ( nrow(xkcd) - 1)
    
      }
  
  MSE.df <- data.frame(h = hs, MSE = MSE)
  
  return(MSE.df)
}

#Testing of function#
test <- hs.xkcd.loocv(0.01,1,0.01)
test[which.min(test$MSE),]


gridx.xkcd <- seq(min(xkcd$x), max(xkcd$x), length.out = length(xkcd$x))



custom_fitted_values <- function(grid, h){
  
  fitted_values <- vector("numeric", length(grid))
  
  for(i in 1:length(grid)){
    
    fitted_values[i] <- sum( xkcd$y * dnorm( (grid[i] - xkcd$x) / h ) ) /
                       sum( dnorm( (grid[i] - xkcd$x) / h ))

  }  
  
  return(fitted_values)
  
}



#Fitted values using cross validated h#
hbest.fitted.values <- custom_fitted_values(gridx.xkcd, 0.2)

grid.fitted <- cbind(gridx.xkcd, hbest.fitted.values)
grid.fitted <- data.frame(grid.fitted)

xkcd %>%
  ggplot() +
  geom_point(aes(x= x, y = y), size = 2) +
  geom_line(inherit.aes = FALSE, data = grid.fitted, aes(x = gridx.xkcd, y = hbest.fitted.values), col = "red")
  
plot(xkcd)
lines(gridx.xkcd, custom_fitted_values(gridx.xkcd, 0.2))
